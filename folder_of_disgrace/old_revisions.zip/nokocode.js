<p id="price_shower" onclick="processForm()">(Do not delete this)..</p>

<script>

// You can modify the prices here!

// EDIT BELOW
//////////////////////////

var icon_headshot = 10;					// Price of regular headshot icons
var icon_pixel = 10;					// Price of pixel icons
var icon_animated_headshot = 15;		// Price of animated pixel icon

var chibi_lineart = 10;					// Price of Chibi Lineart
var chibi_flatcolour = 15;				// Price of Chibi Flatcolour
var chibi_cellshading = 20;
var chibi_softshading = 25;


// DO NOT EDIT BELOW THIS LINE
////////////////////////////

var commission_type = document.forms[0].elements[3];
var rendering_type = document.forms[0].elements[4];
var prev_ss = "";
	
function getPrice(str) {
     var String=str.substring(str.lastIndexOf("$")+1,str.lastIndexOf("]"));
     var price = parseInt(String)
     return price;
}


function configureForIcons() {
	rendering_type.innerHTML = " \
		<option value='[$" + icon_headshot + "] Regular'>[$" + icon_headshot +"] Regular</option>\
		<option value='[$" + icon_pixel + "] Pixel'>[$" + icon_pixel +"] Pixel</option>\
		<option value='[$" + icon_animated_headshot + "] Animated Blinking'>[$" + icon_animated_headshot +"] Animated Blinking</option>\
	";
}

function configureForChibi() {
	rendering_type.innerHTML = " \
		<option value='[$" + chibi_lineart + "] Lineart'>[$" + chibi_lineart +"] Lineart</option>\
		<option value='[$" + chibi_flatcolour + "] Flat Colour'>[$" + chibi_flatcolour +"] Flat Colour</option>\
		<option value='[$" + chibi_cellshading + "] Cell Shading'>[$" + chibi_cellshading +"] Cell Shading</option>\
		<option value='[$" + chibi_softshading + "] Soft Shading'>[$" + chibi_softshading +"] Soft Shading</option>\
	";
}

function processForm() {
	var ss = commission_type.value;
	
	if(ss != prev_ss) {
		if(ss == "Icon") {
			configureForIcons();
		} else if(ss=="Chibi") {
			configureForChibi();
		}
		prev_ss = ss;
	}
	document.getElementById("price_shower").innerHTML = "Price: $" + getPrice(rendering_type.value);
}

var t=setInterval(processForm,100);
</script>