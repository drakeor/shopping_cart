<script>

// You can modify the prices here!

// EDIT BELOW
//////////////////////////




// DO NOT EDIT BELOW THIS LINE
////////////////////////////

</script>

<form action="https://drakeor.com/noko/form.php" enctype="multipart/form-data" method="post" id="nokoform">
        <div class="wsite-form-container"style="margin-top:10px;">
            <div class="formlist" id="509240302256722703-form-list" style="margin-left: 2em">
                <h2 class="wsite-content-title" style="text-align:left;">Commission Form.</h2>

                <div>
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label" for="input-690685893201796614">Have you read and agreed to the <a href="http://little-noko.weebly.com">Terms of Service</a>? <span class=
                        "form-required">*</span></label>

                        <div class="wsite-form-radio-container">
                            <span class='form-radio-container'><input name='tos_agreed' type='radio' value='I agree'><label for=
                            'radio-0-_u690685893201796614'>I agree</label></span>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Have you read and agreed to the &lt;a href=http://little-noko.weebly.com&gt;Terms of Service&lt;/a&gt;?" style=
                        "display:none;">You must agree to this before I can start work on your commission!</div>
                    </div>
                </div>

                <div>
                    <div style="height: 20px; overflow: hidden; width: 100%;"></div>
                    <hr class="styled-hr" style="width:100%;">

                    <div style="height: 20px; overflow: hidden; width: 100%;"></div>
                </div>

                <div>
                    <div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
                        <label class="wsite-form-label" for="input-810854613693251538"><span style="text-decoration: underline">LINK</span> to profile.<br>
                        <small>Please enter a link to either your DA or FA profile</small> <span class="form-required">*</span></label>

                        <div class="wsite-form-input-container">
                            <input class="wsite-form-input wsite-input wsite-input-width-370px" id="input-810854613693251538" name="_u810854613693251538" type="text">
                        </div>

                        <div class="wsite-form-instructions" id="instructions-810854613693251538" style="display:none;">
                            Please enter the FULL link of your profile on FA/DA or your email address.
                        </div>
                    </div>
                </div>

				<!--PAYPAL ADDRESS-->
                <div>
                    <div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
                        <label class="wsite-form-label" for="input-364502280803495396">Paypal Address <span class="form-required">*</span></label>

                        <div class="wsite-form-input-container">
                            <input class="wsite-form-input wsite-input wsite-input-width-370px" id="input-364502280803495396" name="_u364502280803495396" type="text">
                        </div>

                        <div class="wsite-form-instructions" id="instructions-364502280803495396" style="display:none;">
                            You will be invoiced to this address
                        </div>
                    </div>
                </div>

                <div>
                    <div style="height: 20px; overflow: hidden; width: 100%;"></div>
                    <hr class="styled-hr" style="width:100%;">

                    <div style="height: 20px; overflow: hidden; width: 100%;"></div>
                </div>

				<!-- TYPE OF COMMISSION -->
                <div>
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label" for="input-894255476747675510">Type of Commission <span class="form-required">*</span></label>

                        <div class="wsite-form-radio-container">
                            <select class='form-select' name='commission_type'>
                                <option id='1' value='Icon'>Icon</option>
                                <option id='2' value='Chibi'>Chibi</option>
                                <option id='3' value='Headshot'>Headshot</option>
                                <option id='4' value='Pokemon'>Pokemon</option>
                                <option id='5' value='Waist-Up'>Waist-Up</option>
								<option id='6' value='Wing-It'>Wing-it</option>
								<option id='7' value='Fullbody'>Fullbody</option>
                                <option id='8' value='Reference Sheet'>Reference Sheet</option>
                            </select>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Type of Commission" style="display:none;"></div>
                    </div>
                </div>

				<div>
                    <div style="height: 20px; overflow: hidden; width: 100%;"></div>
                    <hr class="styled-hr" style="width:100%;">

                    <div style="height: 20px; overflow: hidden; width: 100%;"></div>
                </div>
				
				<!-- RENDERING TYPE -->
                <div>
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label">Rendering Type <span class="form-required">*</span></label>

                        <div class="wsite-form-radio-container">
                            <select class='form-select' name='rendering_type'>
                                <option value='Lineart'>Error</option>
                            </select>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Rendering Type" style="display:none;"></div>
                    </div>
                </div>

				<!-- ICONS ONLY! Whether or not to add animation-->
				<div id="iconAnimation">
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label">Icon Animation<span class="form-required">*</span></label>

                        <div class="wsite-form-radio-container">
                            <select class='form-select' name='rendering_type'>
                                <option value='[$0] Error'>[$0] Error</option>
                            </select>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Rendering Type" style="display:none;"></div>
                    </div>
                </div>
				
				<!-- NUMBER OF CHARACTERS-->
				<div id="characterCount">
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label">Number of Characters <span class="form-required">*</span></label>

                        <div class="wsite-form-radio-container">
                            <select class='form-select' name='rendering_type'>
                                <option value='[$0] Error'>[$0] Error</option>
                            </select>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Rendering Type" style="display:none;"></div>
                    </div>
                </div>
				
				<!-- BACKGROUND KIND-->
				<div id="backgroundKind">
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label">Background <span class="form-required">*</span></label>

                        <div class="wsite-form-radio-container">
                            <select class='form-select' name='rendering_type'>
                                <option value='[$0] Error'>[$0] Error</option>
                            </select>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Rendering Type" style="display:none;"></div>
                    </div>
                </div>
				
				<!-- Background details-->
				<div id="backgroundDetails">
                    <div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
						<label class="wsite-form-label" for="input-252637277606735691">Additional Background Information <span class="form-required"></span></label>
						<div class="wsite-form-input-container">
							<textarea id="input-252637277606735691" class="wsite-form-input wsite-input wsite-input-width-370px" name="backgroundDetails" style="height: 80px"></textarea>
						</div>
						<div id="instructions-252637277606735691" class="wsite-form-instructions" style="display:none;">If you'd like a custom background, put what you would like here.</div>
					</div></div>
                </div>
				
				<!-- REFERENCE ONLY! Additional Chibi Poses details-->
				<div id="additionalChibiPoses">
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label">Additional Chibi Poses<span class="form-required"></span></label>

                        <div class="wsite-form-radio-container">
                            <select class='form-select' name='rendering_type'>
                                <option value='[$0] Error'>[$0] Error</option>
                            </select>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Rendering Type" style="display:none;"></div>
                    </div>
                </div>
				
				<!-- REFERENCE ONLY! Additional Chibi Poses details-->
				<div id="additionalChibiExplain">
                    <div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
						<label class="wsite-form-label" for="input-252637277606735691">Additional Pose(s) Information <span class="form-required"></span></label>
						<div class="wsite-form-input-container">
							<textarea id="input-252637277606735691" class="wsite-form-input wsite-input wsite-input-width-370px" name="backgroundDetails" style="height: 80px"></textarea>
						</div>
						<div id="instructions-252637277606735691" class="wsite-form-instructions" style="display:none;">If you'd like a custom background, put what you would like here.</div>
					</div></div>
                </div>
				
				<!-- REFERENCE ONLY! Additional Feral Poses details-->
				<div id="additionalFeralPoses">
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label">Additional Feral Poses<span class="form-required"></span></label>

                        <div class="wsite-form-radio-container">
                            <select class='form-select' name='rendering_type'>
                                <option value='[$0] Error'>[$0] Error</option>
                            </select>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Rendering Type" style="display:none;"></div>
                    </div>
                </div>
				
				<!-- REFERENCE ONLY! Additional Feral Poses details-->
				<div id="additionalFeralExplain">
                    <div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
						<label class="wsite-form-label" for="input-252637277606735691">Additional Pose(s) Information <span class="form-required"></span></label>
						<div class="wsite-form-input-container">
							<textarea id="input-252637277606735691" class="wsite-form-input wsite-input wsite-input-width-370px" name="backgroundDetails" style="height: 80px"></textarea>
						</div>
						<div id="instructions-252637277606735691" class="wsite-form-instructions" style="display:none;">If you'd like a custom background, put what you would like here.</div>
					</div></div>
                </div>
				
				<!-- REFERENCE ONLY! Additional Regular Poses details-->
				<div id="additionalAnthroPoses">
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label">Additional Anthro Poses<span class="form-required"></span></label>

                        <div class="wsite-form-radio-container">
                            <select class='form-select' name='rendering_type'>
                                <option value='[$0] Error'>[$0] Error</option>
                            </select>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Rendering Type" style="display:none;"></div>
                    </div>
                </div>
				
				<!-- REFERENCE ONLY! Additional Regular Poses details-->
				<div id="additionalAnthroExplain">
                    <div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
						<label class="wsite-form-label" for="input-252637277606735691">Additional Pose(s) Information <span class="form-required"></span></label>
						<div class="wsite-form-input-container">
							<textarea id="input-252637277606735691" class="wsite-form-input wsite-input wsite-input-width-370px" name="backgroundDetails" style="height: 80px"></textarea>
						</div>
						<div id="instructions-252637277606735691" class="wsite-form-instructions" style="display:none;">If you'd like a custom background, put what you would like here.</div>
					</div></div>
                </div>
				
				<!-- REFERENCE ONLY! Close up details-->
				<div id="additionalCloseups">
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label">Additional Closeups<span class="form-required"></span></label>

                        <div class="wsite-form-radio-container">
                            <select class='form-select' name='rendering_type'>
                                <option value='[$0] Error'>[$0] Error</option>
                            </select>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Rendering Type" style="display:none;"></div>
                    </div>
                </div>
				
				<!-- REFERENCE ONLY! Additional Close-up details-->
				<div id="additionalCloseupsExplain">
                    <div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
						<label class="wsite-form-label" for="input-252637277606735691">Additional Close-up Information <span class="form-required"></span></label>
						<div class="wsite-form-input-container">
							<textarea id="input-252637277606735691" class="wsite-form-input wsite-input wsite-input-width-370px" name="backgroundDetails" style="height: 80px"></textarea>
						</div>
						<div id="instructions-252637277606735691" class="wsite-form-instructions" style="display:none;">If you'd like a custom background, put what you would like here.</div>
					</div></div>
                </div>
				
				<!-- REFERENCE ONLY! Headshots details-->
				<div id="additionalHeadshots">
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label">Additional Headshots<span class="form-required"></span></label>

                        <div class="wsite-form-radio-container">
                            <select class='form-select' name='rendering_type'>
                                <option value='[$0] Error'>[$0] Error</option>
                            </select>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Rendering Type" style="display:none;"></div>
                    </div>
                </div>
				
				<!-- REFERENCE ONLY! Additional Chibi Poses details-->
				<div id="additionalHeadshotsExplain">
                    <div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
						<label class="wsite-form-label" for="input-252637277606735691">Additional Pose(s) Information? <span class="form-required"></span></label>
						<div class="wsite-form-input-container">
							<textarea id="input-252637277606735691" class="wsite-form-input wsite-input wsite-input-width-370px" name="backgroundDetails" style="height: 80px"></textarea>
						</div>
						<div id="instructions-252637277606735691" class="wsite-form-instructions" style="display:none;">If you'd like a custom background, put what you would like here.</div>
					</div></div>
                </div>
				
				<div>
                    <div style="height: 20px; overflow: hidden; width: 100%;"></div>
                    <hr class="styled-hr" style="width:100%;">

                    <div style="height: 20px; overflow: hidden; width: 100%;"></div>
                </div>
				
				
				<!-- References-->
				<div id="references">
                    <div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
						<label class="wsite-form-label" for="input-252637277606735691">Character References<br /><small>Please remember to include a reference for each character!</small> <span class="form-required"></span></label>
						<div class="wsite-form-input-container">
							<textarea id="input-252637277606735691" class="wsite-form-input wsite-input wsite-input-width-370px" name="backgroundDetails" style="height: 100px"></textarea>
						</div>
						<div id="instructions-252637277606735691" class="wsite-form-instructions" style="display:none;"></div>
					</div></div>
                </div>
				
				<!-- Commission Details-->
				<div id="commissionDetails">
                    <div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
						<label class="wsite-form-label" for="input-252637277606735691">Commission Details <br /><small>Description of the expression, pose, and the idea you have in mind</small> <span class="form-required"></span></label>
						<div class="wsite-form-input-container">
							<textarea id="input-252637277606735691" class="wsite-form-input wsite-input wsite-input-width-370px" name="backgroundDetails" style="height: 100px"></textarea>
						</div>
						<div id="instructions-252637277606735691" class="wsite-form-instructions" style="display:none;"></div>
					</div></div>
                </div>
				
				<!-- Additional Information-->
				<div id="additionalInformation">
                    <div><div class="wsite-form-field" style="margin:5px 0px 5px 0px;">
						<label class="wsite-form-label" for="input-252637277606735691">Additional Information <br /><small>Please list any additional information not included above</small><span class="form-required"></span></label>
						<div class="wsite-form-input-container">
							<textarea id="input-252637277606735691" class="wsite-form-input wsite-input wsite-input-width-370px" name="backgroundDetails" style="height: 100px"></textarea>
						</div>
						<div id="instructions-252637277606735691" class="wsite-form-instructions" style="display:none;"></div>
					</div></div>
                </div>
				
				<div>
                    <div class="wsite-form-field" style="margin:5px 0px 0px 0px;">
                        <label class="wsite-form-label" for="input-690685893201796614">Works in Progress?<span class=
                        "form-required">*</span></label>

                        <div class="wsite-form-radio-container">
                            <span class='form-radio-container'><input name='works_in_progress' type='radio' value='Yes'><label for=
                            'radio-0-_u690685893201796614'>Yes</label></span>
							<span class='form-radio-container'><input name='works_in_progress' type='radio' value='No'><label for=
                            'radio-0-_u690685893201796614'>No</label></span>
                        </div>

                        <div class="wsite-form-instructions" id="instructions-Have you read and agreed to the &lt;a href=http://little-noko.weebly.com&gt;Terms of Service&lt;/a&gt;?" style=
                        "display:none;"></div>
                    </div>
                </div>
				
				<!-- END OF FORM -->
                <div>
                    <div style="height: 20px; overflow: hidden; width: 100%;"></div>
                    <hr class="styled-hr" style="width:100%;">

                    <div style="height: 20px; overflow: hidden; width: 100%;"></div>
                </div>
            </div>
        </div>

        <div style="display:none; visibility:hidden;">
            <input name="wsite_subject" type="text">
        </div>
		
		<p id="price_shower" onclick="processForm()">(Do not delete this)..</p>
		
        <div style="text-align:left; margin-top:10px; margin-bottom:10px;">
            <input name="form_version" type="hidden" value="2"> <input id="wsite-approved" name="wsite_approved" type="hidden" value="approved"> <input name="ucfid" type="hidden" value=
            "509240302256722703"> <input style='position:absolute;top:0;left:-9999px;width:1px;height:1px' type='submit'><a class='wsite-button' onclick=
            "document.getElementById('nokoform').submit()"><span class='wsite-button-inner'>Submit</span></a>
        </div>
    </form>

<script>

// EDIT BELOW THIS LINE
////////////////////////////


/// ICON STUFF
//////////////

var icon_headshot = 10;					// Price of regular headshot icons
var icon_pixel = 10;					// Price of pixel icons

var icon_animated_extra = 5;			// Extra cost for animated icons
var icon_additional_character = 5;		// Extra cost of additional character


// CHIBI STUFF
///////////////

var chibi_lineart = 10;					// Price of Chibi Lineart
var chibi_flatcolour = 15;				// Price of Chibi Flat colour
var chibi_cellshading = 20;				// Price of Chibi Cell Shading
var chibi_softshading = 25;				// Price of Chibi Soft shading

var chibi_add_character_1 = 75;			// Percentage for first additional character
var chibi_add_character_2 = 150;		// Percentage for second additional character
var chibi_add_character_3 = 225;		// Percentage for second additional character

var chibi_background = 10;				// Starting price for complicated backgrounds

// HEADSHOT STUFF
////////////////

var headshot_lineart = 10;					// Price of Headshot Lineart
var headshot_flatcolour = 15;				// Price of Headshot Flat colour
var headshot_cellshading = 20;				// Price of Headshot Cell Shading
var headshot_softshading = 25;				// Price of Headshot Soft shading

var headshot_add_character_1 = 75;			// Percentage for first additional character
var headshot_add_character_2 = 150;		// Percentage for second additional character
var headshot_add_character_3 = 225;		// Percentage for second additional character


// WAIST-UP STUFF
///////////////

var waistup_lineart = 15;					// Price of Waist-up Lineart
var waistup_flatcolour = 20;				// Price of Waist-up Flat colour
var waistup_cellshading = 25;				// Price of Waist-up Cell Shading
var waistup_softshading = 30;				// Price of Waist-up Soft shading

var waistup_add_character_1 = 75;			// Percentage for first additional character
var waistup_add_character_2 = 150;		// Percentage for second additional character
var waistup_add_character_3 = 225;		// Percentage for second additional character

var waistup_background = 10;				// Starting price for complicated backgrounds

// FULLBODY STUFF
///////////////

var fullbody_lineart = 25;					// Price of Fullbody Lineart
var fullbody_flatcolour = 30;				// Price of Fullbody Flat colour
var fullbody_cellshading = 35;				// Price of Fullbody Cell Shading
var fullbody_softshading = 40;				// Price of Fullbody Soft shading

var fullbody_add_character_1 = 75;			// Percentage for first additional character
var fullbody_add_character_2 = 150;		// Percentage for second additional character
var fullbody_add_character_3 = 225;		// Percentage for second additional character

var fullbody_background = 10;				// Starting price for complicated backgrounds

// WING-IT 
///////////////

var wingit_chibi = 20;					// Price of Chibi Wing-it
var wingit_fullbody = 30;				// Price of Fullbody Wing-it

var wingit_add_character_1 = 75;		// Percentage for first additional character
var wingit_add_character_2 = 150;		// Percentage for second additional character
var wingit_add_character_3 = 225;		// Percentage for second additional character

var wingit_background = 10;				// Starting price for complicated backgrounds
var wingit_landscape = 20;				// Starting price for wingit landscapes


// REFERENCE SHEETS
///////////////

var reference_chibi_flat = 30;			// Price of Chibi Reference Flat
var reference_chibi_cell = 40;			// Price of Chibi Reference Cell shading
var reference_chibi_soft = 50;			// Price of Chibi Reference Soft shading

var reference_feral_flat = 30;			// Price of Feral Reference Flat
var reference_feral_cell = 40;			// Price of Feral Reference Cell shading
var reference_feral_soft = 50;			// Price of Feral Reference Soft shading

var reference_normal_flat = 50;			// Price of Normal Reference Flat
var reference_normal_cell = 60;			// Price of Normal Reference Cell shading
var reference_normal_soft = 70;			// Price of Normal Reference Soft shading

var reference_chibi_extra_pose = 10;	// Price of an extra pose
var reference_feral_extra_pose = 10;	// Price of an extra pose
var reference_normal_extra_pose = 22;	// Price of an extra pose

var reference_closeup_cost = 5;			// Extra price of closeups
var reference_headshot_cost = 10;		// Extra price of headshots


// DO NOT EDIT BELOW THIS LINE
////////////////////////////

// Initial variables
/////////////////////
var commission_type = document.forms[0].elements[3];
var rendering_type = document.forms[0].elements[4];

var icon_animation_div = document.getElementById("iconAnimation");
var icon_animation_form = document.forms[0].elements[5];

var character_div = document.getElementById("characterCount");
var character_form = document.forms[0].elements[6];

// Background
var background_div = document.getElementById("backgroundKind");
var background_form = document.forms[0].elements[7];

var backgroundExplain_div = document.getElementById("backgroundDetails");
var backgroundExplain_form = document.forms[0].elements[8];

// Extra chibi poses
var extraChibiPoses_div = document.getElementById("additionalChibiPoses");
var extraChibiPoses_form = document.forms[0].elements[9];

var extraChibiExplain_div = document.getElementById("additionalChibiExplain");
var extraChibiExplain_form = document.forms[0].elements[10];

// Extra Feral poses
var extraFeralPoses_div = document.getElementById("additionalFeralPoses");
var extraFeralPoses_form = document.forms[0].elements[11];

var extraFeralExplain_div = document.getElementById("additionalFeralExplain");
var extraFeralExplain_form = document.forms[0].elements[12];

// Extra Anthro poses
var extraAnthroPoses_div = document.getElementById("additionalAnthroPoses");
var extraAnthroPoses_form = document.forms[0].elements[13];

var extraAnthroExplain_div = document.getElementById("additionalAnthroExplain");
var extraAnthroExplain_form = document.forms[0].elements[14];

// Extra closeups
var extraCloseups_div = document.getElementById("additionalCloseups");
var extraCloseups_form  = document.forms[0].elements[15];

var extraCloseupsExplain_div = document.getElementById("additionalCloseupsExplain");
var extraCloseupsExplain_form = document.forms[0].elements[16];

// Extra headshots
var extraHeadshots_div = document.getElementById("additionalHeadshots");
var extraHeadshots_form = document.forms[0].elements[17];

var extraHeadshotsExplain_div = document.getElementById("additionalHeadshotsExplain");
var extraHeadshotsExplain_form = document.forms[0].elements[18];


// Other variables
var prev_ss = "";
var prev_ssb = "";
var prev_ss_r_a = "";
var prev_ss_r_b = "";
var prev_ss_r_c = "";
var prev_ss_r_d = "";
var prev_ss_r_e = "";

// GetPrice returns the price
function getPrice(str) {
     var String=str.substring(str.lastIndexOf("$")+1,str.lastIndexOf("]"));
     var price = parseInt(String)
     return price;
}

// Returns the percent of an option
function getPercent(str) {
     var String=str.substring(str.lastIndexOf("+")+1,str.lastIndexOf("%"));
     var price = parseInt(String)
     return price/100;
}

// Resets all the fields to a default value
function resetFields() {
	icon_animation_div.style.display = 'none';
	icon_animation_form.innerHTML = "<option value='[$0] Nothing'>[$0] Nothing</option>";
	
	character_div.style.display = 'none';
	character_form.innerHTML = "<option value='[$0] Nothing'>[$0] Nothing</option>";
	
	background_div.style.display = 'none';
	background_form.innerHTML = "<option value='[$0] Nothing'>[$0] Nothing</option>";
	
	backgroundExplain_div.style.display = 'none';
	
	extraChibiPoses_div.style.display = 'none';
	extraChibiPoses_form.innerHTML = "<option value='[$0] Nothing'>[$0] Nothing</option>";
	
	extraChibiExplain_div.style.display = 'none';
	
	extraFeralPoses_div.style.display = 'none';
	extraFeralPoses_form.innerHTML = "<option value='[$0] Nothing'>[$0] Nothing</option>";
	
	extraFeralExplain_div.style.display = 'none';
	
	extraAnthroPoses_div.style.display = 'none';
	extraAnthroPoses_form.innerHTML = "<option value='[$0] Nothing'>[$0] Nothing</option>";
	
	extraAnthroExplain_div.style.display = 'none';
	
	extraHeadshots_div.style.display = 'none';
	extraHeadshots_form.innerHTML = "<option value='[$0] Nothing'>[$0] Nothing</option>";
	
	extraHeadshotsExplain_div.style.display = 'none';
	
	extraCloseups_div.style.display = 'none';
	extraCloseups_form.innerHTML = "<option value='[$0] Nothing'>[$0] Nothing</option>";
	
	extraCloseupsExplain_div.style.display = 'none';
}

var pokemon_chibi_team_base = 20;
var pokemon_regular_team_base = 35;
var pokemon_oc_base_price = 20;

// POKEMON
//////////////
function configureForPokemon() {

	// Rendering options
	rendering_type.innerHTML = " \
		<option value='[$" + reference_chibi_flat + "] Chibi Team Soft Shading'>[$" + reference_chibi_flat +"] Chibi Soft Shading</option>\
		<option value='[$" + reference_chibi_cell + "] Regular Team Soft Shading'>[$" + reference_chibi_cell +"] Regular Soft Shading</option>\
		<option value='[$" + reference_chibi_soft + "] Pokemon OC Soft Shading'>[$" + reference_chibi_soft +"] Pokemon OC Soft Shading</option>\
	";
	
}


// REFERENCE SHEETS
//////////////
function configureForReferenceSheet() {

	// Rendering options
	rendering_type.innerHTML = " \
		<option value='[$" + reference_chibi_flat + "] Chibi Flat Color'>[$" + reference_chibi_flat +"] Chibi Flat Color</option>\
		<option value='[$" + reference_chibi_cell + "] Chibi Cell Shading'>[$" + reference_chibi_cell +"] Chibi Cell Shading</option>\
		<option value='[$" + reference_chibi_soft + "] Chibi Soft Shading'>[$" + reference_chibi_soft +"] Chibi Soft Shading</option>\
		<option value='[$" + reference_feral_flat + "] Feral Flat Color'>[$" + reference_feral_flat +"] Feral Flat Color</option>\
		<option value='[$" + reference_feral_cell + "] Feral Cell Shading'>[$" + reference_feral_cell +"] Feral Cell Shading</option>\
		<option value='[$" + reference_feral_soft + "] Feral Soft Shading'>[$" + reference_feral_soft +"] Feral Soft Shading</option>\
		<option value='[$" + reference_normal_flat + "] Normal Flat Color'>[$" + reference_normal_flat +"] Normal Flat Color</option>\
		<option value='[$" + reference_normal_cell + "] Normal Cell Shading'>[$" + reference_normal_cell +"] Normal Cell Shading</option>\
		<option value='[$" + reference_normal_soft + "] Normal Soft Shading'>[$" + reference_normal_soft +"] Normal Soft Shading</option>\
	";
	
	// Additional Chibi Poses
	extraChibiPoses_div.style.display = 'block';
	extraChibiPoses_form.innerHTML = " \
		<option value='[$0] No Extra Poses'>[$0] No Extra Poses</option>\
		<option value='[$" + reference_chibi_extra_pose + "] 1 Extra Chibi Pose'>[$" + reference_chibi_extra_pose +"] 1 Extra Chibi Pose</option>\
		<option value='[$" + reference_chibi_extra_pose*2 + "] 2 Extra Chibi Poses'>[$" + reference_chibi_extra_pose*2 +"] 2 Extra Feral Poses</option>\
		<option value='[$" + reference_chibi_extra_pose*3 + "] 3 Extra Chibi Poses'>[$" + reference_chibi_extra_pose*3 +"] 3 Extra Chibi Poses</option>\
	";
	
	// Additional Feral Poses
	extraFeralPoses_div.style.display = 'block';
	extraFeralPoses_form.innerHTML = " \
		<option value='[$0] No Extra Poses'>[$0] No Extra Poses</option>\
		<option value='[$" + reference_feral_extra_pose + "] 1 Extra Feral Pose'>[$" + reference_feral_extra_pose +"] 1 Extra Feral Pose</option>\
		<option value='[$" + reference_feral_extra_pose*2 + "] 2 Extra Feral Poses'>[$" + reference_feral_extra_pose*2 +"] 2 Extra Feral Poses</option>\
		<option value='[$" + reference_feral_extra_pose*3 + "] 3 Extra Feral Poses'>[$" + reference_feral_extra_pose*3 +"] 3 Extra Feral Poses</option>\
	";
	
	// Additional Anthro Poses
	extraAnthroPoses_div.style.display = 'block';
	extraAnthroPoses_form.innerHTML = " \
		<option value='[$0] No Extra Poses'>[$0] No Extra Poses</option>\
		<option value='[$" + reference_normal_extra_pose + "] 1 Extra Anthro Pose'>[$" + reference_normal_extra_pose +"] 1 Extra Anthro Pose</option>\
		<option value='[$" + reference_normal_extra_pose*2 + "] 2 Extra Anthro Poses'>[$" + reference_normal_extra_pose*2 +"] 2 Extra Anthro Poses</option>\
		<option value='[$" + reference_normal_extra_pose*3 + "] 3 Extra Chibi Poses'>[$" + reference_normal_extra_pose*3 +"] 3 Extra Anthro Poses</option>\
	";
	
	// Additional Headshots
	extraHeadshots_div.style.display = 'block';
	extraHeadshots_form.innerHTML = " \
		<option value='[$0] No Extra Headshots'>[$0] No Extra Headshots</option>\
		<option value='[$" + reference_headshot_cost + "] 1 Extra Headshot'>[$" + reference_headshot_cost +"] 1 Extra Headshot</option>\
		<option value='[$" + reference_headshot_cost*2 + "] 2 Extra Headshots'>[$" + reference_headshot_cost*2 +"] 2 Extra Headshots</option>\
		<option value='[$" + reference_headshot_cost*3 + "] 3 Extra Headshots'>[$" + reference_headshot_cost*3 +"] 3 Extra Headshots</option>\
	";
	
	// Additional Closeups
	extraCloseups_div.style.display = 'block';
	extraCloseups_form.innerHTML = " \
		<option value='[$0] No extra closeups'>[$0] No extra closeups</option>\
		<option value='[$" + reference_closeup_cost + "] 1 Extra Closeup'>[$" + reference_closeup_cost +"] 1 Extra Close-up</option>\
		<option value='[$" + reference_closeup_cost*2 + "] 2 Extra Close-ups'>[$" + reference_closeup_cost*2 +"] 2 Extra Close-ups</option>\
		<option value='[$" + reference_closeup_cost*3 + "] 3 Extra Close-ups'>[$" + reference_closeup_cost*3 +"] 3 Extra Close-ups</option>\
	";
	
	// Background fix
	background_div.style.display = 'none';
	background_form.innerHTML = " \
		<option value='[$0] Basic'>[$0] Basic</option>\
		";
}

// ICONS
/////////////
function configureForIcons() {
	rendering_type.innerHTML = " \
		<option value='[$" + icon_headshot + "] Regular'>[$" + icon_headshot +"] Regular</option>\
		<option value='[$" + icon_pixel + "] Pixel'>[$" + icon_pixel +"] Pixel</option>\
	";
	
	// Show icons
	icon_animation_div.style.display = 'block';
	icon_animation_form.innerHTML = " \
		<option value='[$0] Animated Blinking'>[$0] No Animation</option>\
		<option value='[+$" + icon_animated_extra + "] Animated Blinking'>[+$" + icon_animated_extra +"] Blinking Animation</option>\
	";
	
	// Show character count
	character_div.style.display = 'block';
	character_form.innerHTML = " \
		<option value='[$0] Single Character'>[$0] Single Character</option>\
		<option value='[+$" + icon_additional_character + "] 2 Characters'>[+$" + icon_additional_character +"] 2 Characters</option>\
		<option value='[+$" + icon_additional_character*2 + "] 3 Characters'>[+$" + icon_additional_character*2 +"] 3 Characters</option>\
		<option value='[+$" + icon_additional_character*3 + "] 4 Characters'>[+$" + icon_additional_character*3 +"] 4 Characters</option>\
	";
}

// CHIBI
//////////////
function configureForChibi() {

	// Rendering options
	rendering_type.innerHTML = " \
		<option value='[$" + chibi_lineart + "] Lineart'>[$" + chibi_lineart +"] Lineart</option>\
		<option value='[$" + chibi_flatcolour + "] Flat Colour'>[$" + chibi_flatcolour +"] Flat Colour</option>\
		<option value='[$" + chibi_cellshading + "] Cell Shading'>[$" + chibi_cellshading +"] Cell Shading</option>\
		<option value='[$" + chibi_softshading + "] Soft Shading'>[$" + chibi_softshading +"] Soft Shading</option>\
	";
	
	// Show character count
	character_div.style.display = 'block';
	character_form.innerHTML = " \
		<option value='[+0% of price] Single Character'>[+0% of price] Single Character</option>\
		<option value='[+" + chibi_add_character_1 + "% of rendering price] 2 Characters'>[+" + chibi_add_character_1 + "% of rendering price] 2 Characters</option>\
		<option value='[+" + chibi_add_character_2 + "% of rendering price] 3 Characters'>[+" + chibi_add_character_2 + "% of rendering price] 3 Characters</option>\
		<option value='[+" + chibi_add_character_3 + "% of rendering price ] 4 Characters'>[+" + chibi_add_character_3 + "% of rendering price] 4 Characters</option>\
		";
	
	// Show background options
	background_div.style.display = 'block';
	background_form.innerHTML = " \
		<option value='[$0] Basic'>[$0] Basic</option>\
		<option value='[$" + chibi_background + "] Complex'>[$" + chibi_background + "] Complex (May be more)</option>\
		";
}


// HEADSHOT
//////////////
function configureForHeadshot() {

	// Rendering options
	rendering_type.innerHTML = " \
		<option value='[$" + headshot_lineart + "] Lineart'>[$" + headshot_lineart +"] Lineart</option>\
		<option value='[$" + headshot_flatcolour + "] Flat Colour'>[$" + headshot_flatcolour +"] Flat Colour</option>\
		<option value='[$" + headshot_cellshading + "] Cell Shading'>[$" + headshot_cellshading +"] Cell Shading</option>\
		<option value='[$" + headshot_softshading + "] Soft Shading'>[$" + headshot_softshading +"] Soft Shading</option>\
	";
	
	// Show character count
	character_div.style.display = 'block';
	character_form.innerHTML = " \
		<option value='[+0% of price] Single Character'>[+0% of price] Single Character</option>\
		<option value='[+" + headshot_add_character_1 + "% of rendering price] 2 Characters'>[+" + headshot_add_character_1 + "% of rendering price] 2 Characters</option>\
		<option value='[+" + headshot_add_character_2 + "% of rendering price] 3 Characters'>[+" + headshot_add_character_2 + "% of rendering price] 3 Characters</option>\
		<option value='[+" + headshot_add_character_3 + "% of rendering price ] 4 Characters'>[+" + headshot_add_character_3 + "% of rendering price] 4 Characters</option>\
		";
}

// WAIST-UP
//////////////
function configureForWaistUp() {

	// Rendering options
	rendering_type.innerHTML = " \
		<option value='[$" + waistup_lineart + "] Lineart'>[$" + waistup_lineart +"] Lineart</option>\
		<option value='[$" + waistup_flatcolour + "] Flat Colour'>[$" + waistup_flatcolour +"] Flat Colour</option>\
		<option value='[$" + waistup_cellshading + "] Cell Shading'>[$" + waistup_cellshading +"] Cell Shading</option>\
		<option value='[$" + waistup_softshading + "] Soft Shading'>[$" + waistup_softshading +"] Soft Shading</option>\
	";
	
	// Show character count
	character_div.style.display = 'block';
	character_form.innerHTML = " \
		<option value='[+0% of price] Single Character'>[+0% of price] Single Character</option>\
		<option value='[+" + waistup_add_character_1 + "% of rendering price] 2 Characters'>[+" + waistup_add_character_1 + "% of rendering price] 2 Characters</option>\
		<option value='[+" + waistup_add_character_2 + "% of rendering price] 3 Characters'>[+" + waistup_add_character_2 + "% of rendering price] 3 Characters</option>\
		<option value='[+" + waistup_add_character_3 + "% of rendering price ] 4 Characters'>[+" + waistup_add_character_3 + "% of rendering price] 4 Characters</option>\
		";
	
	// Show background options
	background_div.style.display = 'block';
	background_form.innerHTML = " \
		<option value='[$0] Basic'>[$0] Basic</option>\
		<option value='[$" + waistup_background + "] Complex'>[$" + waistup_background + "] Complex (May be more)</option>\
		";
}

// FULLBODY
//////////////
function configureForFullbody() {

	// Rendering options
	rendering_type.innerHTML = " \
		<option value='[$" + fullbody_lineart + "] Lineart'>[$" + fullbody_lineart +"] Lineart</option>\
		<option value='[$" + fullbody_flatcolour + "] Flat Colour'>[$" + fullbody_flatcolour +"] Flat Colour</option>\
		<option value='[$" + fullbody_cellshading + "] Cell Shading'>[$" + fullbody_cellshading +"] Cell Shading</option>\
		<option value='[$" + fullbody_softshading + "] Soft Shading'>[$" + fullbody_softshading +"] Soft Shading</option>\
	";
	
	// Show character count
	character_div.style.display = 'block';
	character_form.innerHTML = " \
		<option value='[+0% of price] Single Character'>[+0% of price] Single Character</option>\
		<option value='[+" + fullbody_add_character_1 + "% of rendering price] 2 Characters'>[+" + fullbody_add_character_1 + "% of rendering price] 2 Characters</option>\
		<option value='[+" + fullbody_add_character_2 + "% of rendering price] 3 Characters'>[+" + fullbody_add_character_2 + "% of rendering price] 3 Characters</option>\
		<option value='[+" + fullbody_add_character_3 + "% of rendering price ] 4 Characters'>[+" + fullbody_add_character_3 + "% of rendering price] 4 Characters</option>\
		";
	
	// Show background options
	background_div.style.display = 'block';
	background_form.innerHTML = " \
		<option value='[$0] Basic'>[$0] Basic</option>\
		<option value='[$" + fullbody_background + "] Complex'>[$" + fullbody_background + "] Complex (May be more)</option>\
		";
}

// WING-IT
//////////////
function configureForWingit() {

	// Rendering options
	rendering_type.innerHTML = " \
		<option value='[$" + wingit_chibi + "] Chibi Soft Shading'>[$" + wingit_chibi +"] Chibi Soft Shading</option>\
		<option value='[$" + wingit_fullbody + "] Fullbody Soft Shading'>[$" + wingit_fullbody +"] Fullbody Soft Shading</option>\
	";
	
	// Show character count
	character_div.style.display = 'block';
	character_form.innerHTML = " \
		<option value='[+0% of price] Single Character'>[+0% of price] Single Character</option>\
		<option value='[+" + wingit_add_character_1 + "% of rendering price] 2 Characters'>[+" + wingit_add_character_1 + "% of rendering price] 2 Characters</option>\
		<option value='[+" + wingit_add_character_2 + "% of rendering price] 3 Characters'>[+" + wingit_add_character_2 + "% of rendering price] 3 Characters</option>\
		<option value='[+" + wingit_add_character_3 + "% of rendering price ] 4 Characters'>[+" + wingit_add_character_3 + "% of rendering price] 4 Characters</option>\
		";
	
	// Show background options
	background_div.style.display = 'block';
	background_form.innerHTML = " \
		<option value='[$0] No Background'>[$0] No background</option>\
		<option value='[$" + wingit_background + "] Ground beneath character'>[$" + wingit_background + "] Ground beneath character</option>\
		<option value='[$" + wingit_landscape + "] Indoor / Landscape'>[$" + wingit_landscape + "] Indoor / Landscape</option>\
		";
}


// Main Update Logic
//////////////

function processForm() {

	// Variables
	////////////////////
	var renderingPrice = getPrice(rendering_type.value);
	var animationPrice = getPrice(icon_animation_form.value);
	var backgroundPrice = getPrice(background_form.value);
	
	var extraChibiPrice = getPrice(extraChibiPoses_form.value);
	var extraFeralPrice = getPrice(extraFeralPoses_form.value);
	var extraAnthroPrice = getPrice(extraAnthroPoses_form.value);
	var extraHeadshotsPrice = getPrice(extraHeadshots_form.value);
	var extraCloseupsPrice = getPrice(extraCloseups_form.value);
	
	// Recreate the form if the client changes the order type
	////////////////
	var ss = commission_type.value;
	if(ss != prev_ss) {
		resetFields();
		if(ss == "Icon") {
			configureForIcons();
		} else if(ss=="Chibi") {
			configureForChibi();
		} else if(ss=="Headshot") {
			configureForHeadshot();
		} else if(ss=="Waist-Up") {
			configureForWaistUp();
		} else if(ss=="Fullbody") {
			configureForFullbody();
		} else if(ss=="Wing-It") {
			configureForWingit();
		} else if(ss=="Reference Sheet") {
			configureForReferenceSheet();
		}
		
		prev_ss = ss;
	}
	
	// Backgrounds
	var ssb = background_form.value;
	if(ssb != prev_ssb) {
		if(backgroundPrice != 0) {
			backgroundExplain_div.style.display = 'block';
		} else {
			backgroundExplain_div.style.display = 'none';
		}
		prev_ssb = ssb;
	}
	
	// Extra chibi poses
	var ss_r_a = extraChibiPoses_form.value;
	if(ss_r_a != prev_ss_r_a) {
		if(extraChibiPrice != 0) {
			extraChibiExplain_div.style.display = 'block';
		} else {
			extraChibiExplain_div.style.display = 'none';
		}
		prev_ss_r_a = ss_r_a;
	}
	
	// Extra feral poses
	var ss_r_b = extraFeralPoses_form.value;
	if(ss_r_b != prev_ss_r_b) {
		if(extraFeralPrice != 0) {
			extraFeralExplain_div.style.display = 'block';
		} else {
			extraFeralExplain_div.style.display = 'none';
		}
		prev_ss_r_b = ss_r_b;
	}
	
	// Extra anthro poses
	var ss_r_c = extraAnthroPoses_form.value;
	if(ss_r_c != prev_ss_r_c) {
		if(extraAnthroPrice != 0) {
			extraAnthroExplain_div.style.display = 'block';
		} else {
			extraAnthroExplain_div.style.display = 'none';
		}
		prev_ss_r_c = ss_r_c;
	}
	
	// Extra headshots poses
	var ss_r_d = extraHeadshots_form.value;
	if(ss_r_d != prev_ss_r_d) {
		if(extraHeadshotsPrice != 0) {
			extraHeadshotsExplain_div.style.display = 'block';
		} else {
			extraHeadshotsExplain_div.style.display = 'none';
		}
		prev_ss_r_d = ss_r_d;
	}
	
	// Extra closeups
	var ss_r_e = extraCloseups_form.value;
	if(ss_r_e != prev_ss_r_e) {
		if(extraCloseupsPrice != 0) {
			extraCloseupsExplain_div.style.display = 'block';
		} else {
			extraCloseupsExplain_div.style.display = 'none';
		}
		prev_ss_r_e = ss_r_e;
	}
	
	// Initial cost
	// Includes the rendering price, animation, and background
	////////////////////
	var finalPrice = renderingPrice + animationPrice + backgroundPrice;

	// Additional poses and stuff for references
	finalPrice += extraHeadshotsPrice + extraChibiPrice + extraFeralPrice + extraCloseupsPrice + extraAnthroPrice;
	
	// ADDITIONAL CHARACTERS
	////////////////
	
	// For icons, we add the flat rate
	if(ss=="Icon") {
		finalPrice += getPrice(character_form.value);
		
	// For Chibi, Headshot, Waist-Up, and Fullbody type of commissions, we add the percentage to the rendering cost.
	} else if(ss=="Chibi" || ss == "Headshot" || ss=="Waist-Up" || ss=="Fullbody" || ss=="Wing-It") {
		finalPrice = finalPrice + (renderingPrice*getPercent(character_form.value));
	}
	
	// UPDATE THE FORM PRICE
	////////////////
	document.getElementById("price_shower").innerHTML = "<b><span style=\"font-size: 125%\">Estimated Price: <span style=\"color: #0a7f6d\">$" + finalPrice + "</span></span></b><br /><small>This is only an estimate. You may be charged extra for complex details.</small>";
}

var t=setInterval(processForm,100);
</script>